# VK Donuts Python API
## API для работы с приложением для сообществ — VK Donuts!
---
### Для установки библиотеки: ```pip install pydonuts```

### Ссылки:
- [Документация VK Donuts API](https://vkdonuts.ru/api)
- [Группа VK Donuts](https://vk.com/donutsapp)
- [Для обратной связи с разработчиком об ошибках](https://vk.com/thegreywolfer) (*с разработчиком API на Python*)
